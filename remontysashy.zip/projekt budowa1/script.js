const buttons = document.querySelectorAll("[data-carousel-button]")

buttons.forEach(button => {
    button.addEventListener("click", () => {
        const offset = button.dataset.carouselButton === "next" ? 1 : -1
        const slides = button
        .closest("[data-carousel]")
        .querySelector("[data-slides]")

        const activeSlide = slides.querySelector("[data-active]")
        let newIndex = [...slides.children].indexOf(activeSlide) + offset
        if (newIndex < 0) newIndex = slides.children.length - 1
        if (newIndex >= slides.children.length) newIndex = 0

        slides.children[newIndex].dataset.active = true
        delete activeSlide.dataset.active
            })
})
function stopka(){
    var teraz = new Date();
    var data = teraz.toLocaleDateString();
    var godzina = teraz.toLocaleTimeString();
    document.getElementById("data").innerHTML = data;
    document.getElementById("godzina").innerHTML = godzina;
}
setInterval("stopka()", 1000);
function odliczanie(){
    var teraz = new Date();
    var koniec_roku = new Date("2024-12-31") - teraz;
    var data = Math.floor(koniec_roku / (1000 * 60 * 60 * 24));
    var godzina = Math.floor((koniec_roku % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minuta = Math.floor((koniec_roku % (1000 * 60 * 60)) / (1000 * 60));
    var sekunda = Math.floor((koniec_roku % (1000 * 60)) / 1000);
    document.getElementById("zostalo").innerText = data + " dni " + godzina + " godz " + minuta + " min " + sekunda + " s ";
}
setInterval("odliczanie()",1000);