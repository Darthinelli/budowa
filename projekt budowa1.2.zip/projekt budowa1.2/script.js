const buttons = document.querySelectorAll("[data-carousel-button]")

buttons.forEach(button => {
    button.addEventListener("click", () => {
        const offset = button.dataset.carouselButton === "next" ? 1 : -1
        const slides = button
        .closest("[data-carousel]")
        .querySelector("[data-slides]")

        const activeSlide = slides.querySelector("[data-active]")
        let newIndex = [...slides.children].indexOf(activeSlide) + offset
        if (newIndex < 0) newIndex = slides.children.length - 1
        if (newIndex >= slides.children.length) newIndex = 0

        slides.children[newIndex].dataset.active = true
        delete activeSlide.dataset.active
            })
})

function licz(){
        var powierzchnia = parseFloat(document.getElementById('powierzchnia').value);
        var rabat = (document.getElementById('rabat').value);
        var usługa = document.getElementById('usługa').value;
        var cena = 0;
        switch (usługa) {
            case 'remont':
                cena = 100;
                break;
            case 'malowanie':
                cena = 15;
                break;
            case 'podlogi':
                cena = 60;
                break;
            case 'flizowanie':
                cena = 70;
                break;
            default:
                alert('wybierz usługe');
                return;
        }
        if(powierzchnia > 0){
            var koszt = powierzchnia * cena;
        }
        else if(powierzchnia < 0){
            alert('Podaj poprawną powierzchnie')
        }
        if (rabat === 'Strzykawka') {
            koszt = koszt * 0.9;
        }
        document.getElementById('koszt').textContent = "Całkowity koszt: " + koszt.toFixed(2) + ' zł';
}
function resetuj(){
    document.getElementById('koszt').textContent = "";
    document.getElementById('form').reset();
}